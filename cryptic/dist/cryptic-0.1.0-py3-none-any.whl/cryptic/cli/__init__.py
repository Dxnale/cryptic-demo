"""Interfaz de línea de comandos para Cryptic."""
