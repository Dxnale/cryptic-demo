"""Módulo principal con la lógica de identificación y análisis."""
