"""Utilidades para formateo, limpieza y procesamiento de datos."""
